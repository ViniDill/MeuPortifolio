import styled from "styled-components";

export const Container = styled.div`

    text-align: center;
    background-color: #feff;

    h1 {
        font-size: 60px;
    }

    h2 {
        font-size: 40px;
    }

`